class SingleDataCollector:
   
    def __init__(self):
        pass


    def read(self):
        pass