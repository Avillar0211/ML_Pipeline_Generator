class SingleDataCleaner:
    
    def __init__(self):
        pass


    def clean(self):
        pass

