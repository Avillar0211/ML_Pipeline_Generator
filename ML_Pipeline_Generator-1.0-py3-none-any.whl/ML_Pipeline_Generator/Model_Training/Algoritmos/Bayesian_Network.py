from ML_Pipeline_Generator.Model_Training.Algoritmos.Single_ModelTrainer import SingleModelTrainer

class BayesianNetworkAL(SingleModelTrainer):

    def __init__(self, propierties):
        super().__init__()
        

    def train():
        return