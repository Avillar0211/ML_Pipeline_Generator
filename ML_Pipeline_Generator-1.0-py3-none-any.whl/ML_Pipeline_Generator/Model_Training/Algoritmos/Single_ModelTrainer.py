
class SingleModelTrainer():

    def __init__(self):
        return
    
    def train(dFrame):
        pass