class SingleDataFeature:
    
    def __init__(self):
        pass

    def feature(self):
        pass

