
class SingleModelValidator():

    def __init__(self):
        return
    
    def validate():
        pass