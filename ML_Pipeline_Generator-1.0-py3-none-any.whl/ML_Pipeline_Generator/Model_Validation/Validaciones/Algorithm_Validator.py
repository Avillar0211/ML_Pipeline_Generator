
class Algorithm_Validator():

    def __init__(self):
        return
    
    def validate():
        pass