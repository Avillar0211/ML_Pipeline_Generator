class single_data_transformator:
    
    def __init__(self):
        pass

    def transform(self):
        pass

