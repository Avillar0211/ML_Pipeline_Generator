from ML_Pipeline_Generator.Model_Training.Model_Trainer import ModelTrainer
from sklearn.model_selection import train_test_split
import pandas
from sklearn import linear_model
from sklearn.preprocessing import LabelEncoder
import numpy as np

try:
    trainer = ModelTrainer(None,[])
    #propierties = {'max_iter': 10000,}
    #trainer.load_algorithm("LogisticRegression", propierties)
    model = trainer.model_Training()
except Exception as e:
    print(e)

