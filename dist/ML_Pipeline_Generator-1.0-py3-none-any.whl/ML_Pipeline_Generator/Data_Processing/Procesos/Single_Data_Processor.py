class single_data_processor:
    
    def __init__(self):
        pass


    def process(self):
        pass

