
class Algorithm_Trainer():

    def __init__(self):
        return
    
    def train(dFrame):
        pass