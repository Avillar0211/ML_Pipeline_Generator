from ML_Pipeline_Generator. Model_Training.Algoritmos.Algorithm_Trainer import Algorithm_Trainer

class BayesianNetworkAL(Algorithm_Trainer):

    def __init__(self, propierties):
        super().__init__()
        

    def train():
        return