class single_data_feature:
    
    def __init__(self):
        pass

    def feature(self):
        pass

